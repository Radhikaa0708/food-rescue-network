import { useState } from "react";

const STATS = [
  { value: "40%", fill: 40, body: "of food produced globally is never eaten" },
  { value: "< 2 hrs", fill: 70, body: "typical window before surplus food is unsafe to donate" },
  { value: "1 in 9", fill: 55, body: "people affected by hunger while this surplus goes to waste" },
];

export default function ProblemSection() {
  const [active, setActive] = useState(null);

  return (
    <section id="problem" className="section">
      <div className="problem-block">
        <div>
          <h2>The gap isn't food. It's coordination.</h2>
          <p>
            Edible food is discarded daily by restaurants, hostels, events and households — while
            nearby organizations need exactly that food. The bottleneck is rarely awareness. It's
            timing, logistics, and knowing who's close enough to move fast.
          </p>
          <p style={{ marginTop: 14 }}>
            Rescue Route replaces scattered calls and WhatsApp forwards with one coordinated
            pipeline: list, claim, deliver.
          </p>
        </div>
        <div className="problem-stats">
          {STATS.map((s, i) => (
            <div
              className={`pstat${active === i ? " active" : ""}`}
              key={s.value}
              onMouseEnter={() => setActive(i)}
              onMouseLeave={() => setActive(null)}
            >
              <b>{s.value}</b>
              <span>{s.body}</span>
              <div className="pstat-bar">
                <span className="pstat-fill" style={{ width: active === i ? `${s.fill}%` : "6%" }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
