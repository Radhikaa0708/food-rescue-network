import { useState } from "react";

const STEPS = [
  {
    num: "STEP 01",
    title: "List surplus food",
    body: "Providers post quantity, type, pickup window and expiry — takes under a minute.",
    detail: "Snap a photo, pick a category, set the pickup window. Listings go live to nearby volunteers instantly.",
  },
  {
    num: "STEP 02",
    title: "Verified claim",
    body: "Nearby NGOs or volunteers see it ranked by urgency and distance, and claim in one tap.",
    detail: "Claims lock the listing so two volunteers never show up for the same pickup — no wasted trips.",
  },
  {
    num: "STEP 03",
    title: "Tracked delivery",
    body: "Pickup and drop-off status stays visible end-to-end, so nothing silently falls through.",
    detail: "Providers and recipients both see live status: claimed → picked up → delivered, timestamped.",
  },
];

export default function HowItWorks() {
  const [active, setActive] = useState(0);

  return (
    <section id="how" className="section">
      <div className="section-head">
        <div className="eyebrow mono">How it works</div>
        <h2>Provider lists it. Volunteer claims it. Recipient gets it.</h2>
      </div>
      <div className="flow">
        <div className="flow-line">
          <span
            className="flow-line-fill"
            style={{ width: `${(active / (STEPS.length - 1)) * 100}%` }}
          />
        </div>
        {STEPS.map((step, i) => (
          <button
            type="button"
            className={`flow-card${active === i ? " active" : ""}`}
            key={step.num}
            onClick={() => setActive(i)}
          >
            <span className="flow-num mono">{step.num}</span>
            <h3>{step.title}</h3>
            <p>{step.body}</p>
            {active === i && <p className="flow-detail">{step.detail}</p>}
          </button>
        ))}
      </div>
    </section>
  );
}
