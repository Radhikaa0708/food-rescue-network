import { useState, useMemo } from "react";
import { LISTINGS, CATEGORIES } from "../data/listings.js";

const URGENCY_FILTERS = [
  { key: "all", label: "All urgency" },
  { key: "urgent", label: "Urgent" },
  { key: "soon", label: "Expiring soon" },
  { key: "fresh", label: "Fresh" },
];

export default function LiveBoard() {
  const [urgency, setUrgency] = useState("all");
  const [category, setCategory] = useState("all");
  const [claimedIds, setClaimedIds] = useState([]);

  const visible = useMemo(
    () =>
      LISTINGS.filter(
        (l) =>
          (urgency === "all" || l.tag === urgency) &&
          (category === "all" || l.category === category)
      ),
    [urgency, category]
  );

  return (
    <section id="board" className="section">
      <div className="section-head">
        <div className="eyebrow mono">Live board · demo</div>
        <h2>See it move.</h2>
        <p>A sample of what providers and volunteers see in real time. Filter by food type or urgency, claim a listing, and see who picked it up.</p>
      </div>

      <div className="board">
        <div className="board-header">
          {URGENCY_FILTERS.map((f) => (
            <button
              key={f.key}
              className={`chip mono${urgency === f.key ? " active" : ""}`}
              onClick={() => setUrgency(f.key)}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="board-header category-chips">
          {CATEGORIES.map((c) => (
            <button
              key={c.key}
              className={`chip mono${category === c.key ? " active" : ""}`}
              onClick={() => setCategory(c.key)}
            >
              <span className="chip-emoji">{c.emoji}</span> {c.label}
            </button>
          ))}
        </div>

        <div className="board-list">
          {visible.length === 0 && (
            <p className="board-empty">No listings match those filters right now.</p>
          )}
          {visible.map((item) => {
            const isClaimed = claimedIds.includes(item.id) || !!item.claimedBy;
            const claimer = item.claimedBy || (claimedIds.includes(item.id)
              ? { name: "You", org: "This account", area: "Your pickup" }
              : null);
            return (
              <div className="row" key={item.id}>
                <div className="row-item-main">
                  <span className="food-emoji row-food-emoji" role="img" aria-label={item.category}>{item.emoji}</span>
                  <div>
                    <span className="item-name">{item.name}</span>
                    <span className="item-sub">{item.provider} · {item.area} · {item.distanceKm.toFixed(1)} km</span>
                  </div>
                </div>
                <div><span className={`row-tag ${item.tag} mono`}>{item.expiry}</span></div>
                <div className="mono">Qty: {item.qty}</div>
                <div className="mono">
                  {isClaimed && claimer
                    ? `Claimed by ${claimer.name} (${claimer.org})`
                    : `Pickup: ${item.pickup}`}
                </div>
                <button
                  className={`row-claim${isClaimed ? " done" : ""}`}
                  disabled={isClaimed}
                  onClick={() => setClaimedIds((prev) => [...prev, item.id])}
                >
                  {isClaimed ? "Claimed" : "Claim"}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
