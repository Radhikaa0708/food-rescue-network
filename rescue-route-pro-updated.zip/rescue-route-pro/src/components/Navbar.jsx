import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

export default function Navbar() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const goToSection = (id) => (e) => {
    e.preventDefault();
    if (pathname === "/home") {
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    } else {
      navigate(`/home#${id}`);
    }
  };

  return (
    <header className={`site-header${scrolled ? " scrolled" : ""}`}>
      <div className="nav-wrap">
        <Link to="/home" className="brand">
          <div className="brand-mark">R</div>
          <div className="brand-name">Rescue Route</div>
        </Link>

        <ul className="nav-list">
          <li><a href="/home#problem" onClick={goToSection("problem")}>The Problem</a></li>
          <li><a href="/home#how" onClick={goToSection("how")}>How It Works</a></li>
          <li><a href="/home#features" onClick={goToSection("features")}>Features</a></li>
          <li>
            <Link to="/dashboard" className={pathname === "/dashboard" ? "active" : ""}>
              Dashboard
            </Link>
          </li>
          <li>
            <Link to="/login" className={pathname === "/login" ? "active" : ""}>
              Log In
            </Link>
          </li>
        </ul>

        <Link to="/login" className="nav-cta">
          List Surplus
        </Link>
      </div>
    </header>
  );
}
