import { useEffect, useRef, useState } from "react";
import TicketCard from "./TicketCard.jsx";

function useCountUp(target, decimals = 0, duration = 1400) {
  const [value, setValue] = useState(0);
  const started = useRef(false);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const start = performance.now();
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(target * eased);
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [target, duration]);

  return value.toFixed(decimals);
}

export default function Hero() {
  const kg = useCountUp(4820, 0);
  const pct = useCountUp(96, 0);
  const volunteers = useCountUp(312, 0);

  return (
    <section className="hero">
      <div className="hero-bg-grid" />
      <div className="hero-bg-floaters">
        <span className="floater floater-0">🍞</span>
        <span className="floater floater-3">🥗</span>
        <span className="floater floater-6">🍛</span>
      </div>
      <div className="hero-copy">
        <div className="eyebrow mono">Live in 6 cities · Pilot phase</div>
        <h1>
          Good food shouldn't <em>run out the clock.</em>
        </h1>
        <p className="lede">
          Rescue Route connects restaurants, hostels and event kitchens with verified NGOs and
          volunteers — so surplus food gets claimed and delivered before it expires, not after.
        </p>
        <div className="hero-ctas">
          <button className="btn-primary">List Surplus Food</button>
          <a href="#board" className="btn-ghost">Browse Donations</a>
        </div>
        <div className="stat-row">
          <div className="stat">
            <b>{kg} kg</b>
            <span className="mono">FOOD RESCUED</span>
          </div>
          <div className="stat">
            <b>{pct}%</b>
            <span className="mono">CLAIMED BEFORE EXPIRY</span>
          </div>
          <div className="stat">
            <b>{volunteers}</b>
            <span className="mono">ACTIVE VOLUNTEERS</span>
          </div>
        </div>
      </div>
      <TicketCard />
    </section>
  );
}
