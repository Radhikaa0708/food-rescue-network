import { useState } from "react";
import { Link } from "react-router-dom";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
    setEmail("");
  };

  return (
    <footer className="site-footer-full">
      <div className="footer-grid">
        <div className="footer-brand-col">
          <div className="brand">
            <div className="brand-mark">R</div>
            <div className="brand-name">Rescue Route</div>
          </div>
          <p className="footer-tagline">
            Coordinating surplus food to the people who need it — before the clock runs out.
          </p>
          <div className="footer-social">
            <a href="#" aria-label="Instagram" onClick={(e) => e.preventDefault()}>📷</a>
            <a href="#" aria-label="Twitter/X" onClick={(e) => e.preventDefault()}>🐦</a>
            <a href="#" aria-label="LinkedIn" onClick={(e) => e.preventDefault()}>💼</a>
            <a href="#" aria-label="GitHub" onClick={(e) => e.preventDefault()}>💻</a>
          </div>
        </div>

        <div className="footer-col">
          <h4 className="mono">Platform</h4>
          <a href="/home#problem">The Problem</a>
          <a href="/home#how">How It Works</a>
          <a href="/home#features">Features</a>
          <Link to="/dashboard">Dashboard</Link>
        </div>

        <div className="footer-col">
          <h4 className="mono">Account</h4>
          <Link to="/login">Log In</Link>
          <Link to="/login">Sign Up</Link>
          <a href="#forgot">Forgot Password</a>
        </div>

        <div className="footer-col footer-newsletter">
          <h4 className="mono">Stay in the loop</h4>
          <p>Get updates on new cities and features.</p>
          {subscribed ? (
            <div className="footer-subscribed">✅ You're on the list!</div>
          ) : (
            <form onSubmit={handleSubscribe} className="footer-form">
              <input
                type="email"
                placeholder="you@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <button type="submit">Join</button>
            </form>
          )}
        </div>
      </div>

      <div className="footer-bottom mono">
        RESCUE ROUTE — HACKATHON PROTOTYPE · BUILT FOR FOOD RESCUE NETWORK
      </div>
    </footer>
  );
}
