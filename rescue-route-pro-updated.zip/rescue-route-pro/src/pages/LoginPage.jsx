import { useState, useEffect, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";

const ROLES = [
  { key: "provider", label: "Food Provider", icon: "🍞", copy: "List surplus food the moment it's ready for pickup." },
  { key: "volunteer", label: "Volunteer", icon: "🚴", copy: "Claim nearby pickups and get food where it's needed fast." },
  { key: "ngo", label: "NGO / Shelter", icon: "🏠", copy: "Coordinate incoming donations for the people you serve." },
];

const TICKETS = [
  { id: "#RR-2291", tag: "Urgent", emoji: "🍞", title: "Bakery Surplus — 18 Trays", route: "Riverside Bakery → Hope Shelter" },
  { id: "#RR-2308", tag: "Soon", emoji: "🍛", title: "Rice & Curry — 25 Boxes", route: "Hotel Meridian → Sewa Foundation" },
  { id: "#RR-2314", tag: "Fresh", emoji: "🥗", title: "Mixed Salads — 20 Boxes", route: "Healthy Bites Cafe → Anna Seva Trust" },
];

const ACTIVITY = [
  { text: "Ravi K. claimed Rice & Curry Boxes", place: "Kidwai Nagar", time: "just now" },
  { text: "Sunrise Bakery listed 60 Bread Loaves", place: "Civil Lines", time: "2 min ago" },
  { text: "Priya S. picked up Sandwich Packs", place: "Panki", time: "6 min ago" },
  { text: "Amit V. claimed Gulab Jamun Trays", place: "Nawabganj", time: "11 min ago" },
  { text: "Juice Junction listed 35 Bottles", place: "Govind Nagar", time: "18 min ago" },
];

const FLOATERS = ["🍞","🥗","🍛","🍡","🧃","🥟","🍉","🥛"];

export default function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState("login"); // login | signup
  const [role, setRole] = useState("volunteer");
  const [showPw, setShowPw] = useState(false);
  const [agree, setAgree] = useState(false);
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [ticketIndex, setTicketIndex] = useState(0);
  const [activityIndex, setActivityIndex] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setTicketIndex((i) => (i + 1) % TICKETS.length), 4000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setActivityIndex((i) => (i + 1) % ACTIVITY.length), 3200);
    return () => clearInterval(t);
  }, []);

  const update = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const pwStrength = useMemo(() => {
    const p = form.password;
    let score = 0;
    if (p.length >= 6) score++;
    if (p.length >= 10) score++;
    if (/[A-Z]/.test(p) && /[0-9]/.test(p)) score++;
    if (/[^A-Za-z0-9]/.test(p)) score++;
    return Math.min(score, 4);
  }, [form.password]);

  const strengthLabel = ["Too short", "Weak", "Okay", "Good", "Strong"][pwStrength];

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate("/dashboard");
  };

  const ticket = TICKETS[ticketIndex];
  const activity = ACTIVITY[activityIndex];
  const activeRole = ROLES.find((r) => r.key === role);

  return (
    <div className="auth-page">
      <div className="auth-glow glow-a" />
      <div className="auth-glow glow-b" />
      <div className="auth-glow glow-c" />
      <div className="auth-grid-overlay" />
      <div className="auth-floaters">
        {FLOATERS.map((f, i) => (
          <span key={i} className={`floater floater-${i}`}>{f}</span>
        ))}
      </div>

      <div className="auth-shell">
        {/* left / brand side */}
        <div className="auth-side">
          <Link to="/home" className="brand auth-brand">
            <div className="brand-mark">R</div>
            <div className="brand-name">Rescue Route</div>
          </Link>

          <h1 className="auth-side-title">
            Every plate saved <em>starts here.</em>
          </h1>
          <p className="auth-side-lede">{activeRole.copy}</p>

          <div className="role-select">
            {ROLES.map((r) => (
              <button
                key={r.key}
                type="button"
                className={`role-chip${role === r.key ? " active" : ""}`}
                onClick={() => setRole(r.key)}
              >
                <span className="role-icon">{r.icon}</span>
                {r.label}
              </button>
            ))}
          </div>

          <div className="auth-stats">
            <div className="stat">
              <b>12.4k</b>
              <span>meals rescued</span>
            </div>
            <div className="stat">
              <b>340+</b>
              <span>active partners</span>
            </div>
            <div className="stat">
              <b>98%</b>
              <span>on-time pickups</span>
            </div>
          </div>

          <div className="auth-ticket-mini" key={ticket.id}>
            <div className="ticket-top">
              <span className="ticket-id">{ticket.id}</span>
              <span className="urgency-tag">{ticket.tag}</span>
            </div>
            <h3><span className="food-emoji" style={{ marginRight: 8, verticalAlign: "middle" }}>{ticket.emoji}</span>{ticket.title}</h3>
            <div className="ticket-meta">{ticket.route}</div>
            <div className="ticket-dots">
              {TICKETS.map((_, i) => (
                <span key={i} className={i === ticketIndex ? "dot active" : "dot"} />
              ))}
            </div>
          </div>

          <div className="activity-feed" key={activityIndex}>
            <span className="activity-dot" />
            <span className="activity-text">{activity.text} · <em>{activity.place}</em></span>
            <span className="activity-time mono">{activity.time}</span>
          </div>
        </div>

        {/* right / form side */}
        <div className="auth-form-wrap">
          <div className="auth-card">
            <div className="auth-tabs">
              <button
                type="button"
                className={mode === "login" ? "active" : ""}
                onClick={() => setMode("login")}
              >
                Log In
              </button>
              <button
                type="button"
                className={mode === "signup" ? "active" : ""}
                onClick={() => setMode("signup")}
              >
                Sign Up
              </button>
              <span className={`auth-tab-indicator ${mode}`} />
            </div>

            <h2 className="auth-heading">
              {mode === "login" ? "Welcome back" : "Join the network"}
            </h2>
            <p className="auth-subheading">
              {mode === "login"
                ? `Log in as a ${activeRole.label.toLowerCase()} to reach your dashboard.`
                : `Create a ${activeRole.label.toLowerCase()} account to start today.`}
            </p>

            <div className="auth-social">
              <button type="button" className="social-btn google-btn">
                <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                  <path fill="#EA4335" d="M12 10.2v3.9h5.5c-.24 1.4-1.7 4.1-5.5 4.1-3.3 0-6-2.7-6-6.2s2.7-6.2 6-6.2c1.9 0 3.15.8 3.87 1.5l2.64-2.55C16.86 3.15 14.66 2.1 12 2.1 6.98 2.1 2.9 6.18 2.9 11.2s4.08 9.1 9.1 9.1c5.25 0 8.74-3.7 8.74-8.9 0-.6-.07-1.05-.15-1.5H12z"/>
                </svg>
                Continue with Google
              </button>
              <button type="button" className="social-btn discord-btn">
                <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="currentColor">
                  <path d="M20.3 5.4A17.5 17.5 0 0 0 15.9 4c-.2.4-.4.9-.6 1.3a16.3 16.3 0 0 0-6.6 0A9.6 9.6 0 0 0 8.1 4a17.5 17.5 0 0 0-4.4 1.4C1 10 .4 14.4.7 18.8a17.6 17.6 0 0 0 5.3 2.7c.4-.6.8-1.2 1.1-1.9-.6-.2-1.2-.5-1.7-.9l.4-.3c3.4 1.6 7 1.6 10.3 0l.4.3c-.6.4-1.1.7-1.7.9.3.7.7 1.3 1.1 1.9a17.5 17.5 0 0 0 5.3-2.7c.4-5.1-.9-9.5-3.9-13.4ZM8.7 16.2c-1 0-1.9-1-1.9-2.1s.8-2.1 1.9-2.1 1.9 1 1.9 2.1-.8 2.1-1.9 2.1Zm6.6 0c-1 0-1.9-1-1.9-2.1s.8-2.1 1.9-2.1 1.9 1 1.9 2.1-.9 2.1-1.9 2.1Z"/>
                </svg>
                Continue with Discord
              </button>
            </div>

            <div className="auth-divider">
              <span>or continue with username</span>
            </div>

            <form className="auth-form" onSubmit={handleSubmit}>
              <label className="field">
                <span>Username</span>
                <div className="input-icon-wrap">
                  <span className="input-icon">👤</span>
                  <input
                    type="text"
                    placeholder="e.g. riverside_bakery"
                    value={form.username}
                    onChange={update("username")}
                    required
                  />
                </div>
              </label>

              {mode === "signup" && (
                <label className="field">
                  <span>Email</span>
                  <div className="input-icon-wrap">
                    <span className="input-icon">✉️</span>
                    <input
                      type="email"
                      placeholder="you@organization.org"
                      value={form.email}
                      onChange={update("email")}
                      required
                    />
                  </div>
                </label>
              )}

              <label className="field">
                <span>Password</span>
                <div className="pw-input input-icon-wrap">
                  <span className="input-icon">🔒</span>
                  <input
                    type={showPw ? "text" : "password"}
                    placeholder="••••••••"
                    value={form.password}
                    onChange={update("password")}
                    required
                  />
                  <button
                    type="button"
                    className="pw-toggle"
                    onClick={() => setShowPw((s) => !s)}
                  >
                    {showPw ? "Hide" : "Show"}
                  </button>
                </div>
                {mode === "signup" && form.password && (
                  <div className="pw-strength">
                    <div className="pw-strength-bar">
                      <span className={`pw-strength-fill s${pwStrength}`} />
                    </div>
                    <span className="pw-strength-label mono">{strengthLabel}</span>
                  </div>
                )}
              </label>

              {mode === "login" ? (
                <div className="auth-row">
                  <label className="remember">
                    <input type="checkbox" />
                    Remember me
                  </label>
                  <a href="#forgot" className="forgot-link">Forgot password?</a>
                </div>
              ) : (
                <label className="remember terms-row">
                  <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} required />
                  I agree to the Terms of Service and Data Handling Policy
                </label>
              )}

              <button type="submit" className="btn-primary auth-submit" disabled={mode === "signup" && !agree}>
                {mode === "login" ? "Log In" : "Create Account"}
              </button>
            </form>

            <p className="auth-switch">
              {mode === "login" ? (
                <>Don't have an account?{" "}
                  <button type="button" onClick={() => setMode("signup")}>Sign up</button>
                </>
              ) : (
                <>Already have an account?{" "}
                  <button type="button" onClick={() => setMode("login")}>Log in</button>
                </>
              )}
            </p>

            <div className="trust-row mono">
              🔒 Encrypted login · Trusted by 340+ partners across India
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
