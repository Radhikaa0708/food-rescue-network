import { useState, useMemo, useEffect, useRef } from "react";
import { LISTINGS, CATEGORIES } from "../data/listings.js";

function useCountUp(target, duration = 900) {
  const [value, setValue] = useState(0);
  const prevTarget = useRef(0);

  useEffect(() => {
    const from = prevTarget.current;
    const start = performance.now();
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(from + (target - from) * eased));
      if (progress < 1) requestAnimationFrame(tick);
      else prevTarget.current = target;
    };
    requestAnimationFrame(tick);
  }, [target, duration]);

  return value;
}

const ACTIVITY = [
  { text: "Ravi K. claimed Rice & Curry Boxes", place: "Kidwai Nagar", time: "just now" },
  { text: "Sunrise Bakery listed 60 Bread Loaves", place: "Civil Lines", time: "2 min ago" },
  { text: "Priya S. picked up Sandwich Packs", place: "Panki", time: "6 min ago" },
  { text: "Amit V. claimed Gulab Jamun Trays", place: "Nawabganj", time: "11 min ago" },
  { text: "Juice Junction listed 35 Bottles", place: "Govind Nagar", time: "18 min ago" },
];

const SORTS = [
  { key: "near", label: "Nearest" },
  { key: "urgent", label: "Most urgent" },
  { key: "recent", label: "Newest" },
];

export default function DashboardPage() {
  const [claimedIds, setClaimedIds] = useState([]);
  const [category, setCategory] = useState("all");
  const [query, setQuery] = useState("");
  const [sortBy, setSortBy] = useState("recent");
  const [activityIndex, setActivityIndex] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setActivityIndex((i) => (i + 1) % ACTIVITY.length), 3400);
    return () => clearInterval(t);
  }, []);

  const withClaims = useMemo(
    () =>
      LISTINGS.map((item) =>
        claimedIds.includes(item.id) && !item.claimedBy
          ? { ...item, claimedBy: { name: "You", org: "This account", area: "Your pickup" } }
          : item
      ),
    [claimedIds]
  );

  const filtered = useMemo(() => {
    let list = withClaims.filter((l) => category === "all" || l.category === category);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (l) =>
          l.name.toLowerCase().includes(q) ||
          l.provider.toLowerCase().includes(q) ||
          l.category.toLowerCase().includes(q) ||
          l.area.toLowerCase().includes(q)
      );
    }
    const urgencyRank = { urgent: 0, soon: 1, fresh: 2 };
    if (sortBy === "near") list = [...list].sort((a, b) => a.distanceKm - b.distanceKm);
    else if (sortBy === "urgent") list = [...list].sort((a, b) => urgencyRank[a.tag] - urgencyRank[b.tag]);
    else list = [...list].sort((a, b) => b.id - a.id);
    return list;
  }, [withClaims, category, query, sortBy]);

  const rawStats = useMemo(() => {
    const urgent = withClaims.filter((l) => l.tag === "urgent").length;
    const claimed = withClaims.filter((l) => l.claimedBy).length;
    return {
      total: withClaims.length,
      urgent,
      claimed,
      open: withClaims.length - claimed,
    };
  }, [withClaims]);

  const total = useCountUp(rawStats.total);
  const urgent = useCountUp(rawStats.urgent);
  const open = useCountUp(rawStats.open);
  const claimed = useCountUp(rawStats.claimed);

  const nearbyPoints = useMemo(() => {
    const byArea = {};
    withClaims.forEach((l) => {
      if (!byArea[l.area] || l.distanceKm < byArea[l.area].distanceKm) {
        byArea[l.area] = { area: l.area, distanceKm: l.distanceKm, count: 0, emoji: l.emoji };
      }
      byArea[l.area].count += 1;
    });
    return Object.values(byArea).sort((a, b) => a.distanceKm - b.distanceKm);
  }, [withClaims]);

  const handleClaim = (id) => {
    setClaimedIds((prev) => [...prev, id]);
  };

  const activity = ACTIVITY[activityIndex];

  return (
    <div className="dashboard">
      <div className="dash-bg-grid" />
      <div className="dash-head">
        <div>
          <h1>Dispatch Dashboard</h1>
          <p>Track live surplus listings and manage pickups across your network.</p>
        </div>
        <button className="btn-primary">+ New Listing</button>
      </div>

      <div className="dash-activity-ticker" key={activityIndex}>
        <span className="activity-dot" />
        <span className="activity-text">{activity.text} · <em>{activity.place}</em></span>
        <span className="activity-time mono">{activity.time}</span>
      </div>

      <div className="dash-cards">
        <div className="dash-card">
          <span className="mono">TOTAL LISTINGS</span>
          <b>{total}</b>
        </div>
        <div className="dash-card alert">
          <span className="mono">URGENT</span>
          <b>{urgent}</b>
        </div>
        <div className="dash-card">
          <span className="mono">OPEN</span>
          <b>{open}</b>
        </div>
        <div className="dash-card">
          <span className="mono">CLAIMED</span>
          <b>{claimed}</b>
        </div>
      </div>

      {/* Nearby pickup points */}
      <div className="dash-toolbar">
        <h2>Nearby Pickup Points</h2>
      </div>
      <div className="nearby-grid">
        {nearbyPoints.map((p) => (
          <div className="nearby-card" key={p.area}>
            <div className="nearby-pin">
              <span className="food-emoji">{p.emoji}</span>
              <span className="pin-mark">📍</span>
            </div>
            <div className="nearby-info">
              <b>{p.area}</b>
              <span className="mono">{p.distanceKm.toFixed(1)} km away · {p.count} listing{p.count > 1 ? "s" : ""}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="dash-toolbar">
        <h2>Active Listings</h2>
        <div className="dash-controls">
          <input
            className="dash-search"
            type="text"
            placeholder="Search meals, salads, bakery, sweets…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <div className="sort-toggle">
            {SORTS.map((s) => (
              <button
                key={s.key}
                type="button"
                className={sortBy === s.key ? "active" : ""}
                onClick={() => setSortBy(s.key)}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="category-chips">
        {CATEGORIES.map((c) => (
          <button
            key={c.key}
            className={`chip mono${category === c.key ? " active" : ""}`}
            onClick={() => setCategory(c.key)}
          >
            <span className="chip-emoji">{c.emoji}</span> {c.label}
          </button>
        ))}
      </div>

      <div className="dash-table-wrap">
        <table className="dash-table">
          <thead>
            <tr>
              <th></th>
              <th>Item</th>
              <th>Source</th>
              <th>Location</th>
              <th>Status</th>
              <th>Quantity</th>
              <th>Pickup Window</th>
              <th>Claimed By</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={9} className="dash-empty">No listings match your search yet.</td>
              </tr>
            )}
            {filtered.map((item) => {
              const isClaimed = !!item.claimedBy;
              return (
                <tr key={item.id} className="dash-row">
                  <td className="food-emoji-cell">
                    <span className="food-emoji" role="img" aria-label={item.category}>{item.emoji}</span>
                  </td>
                  <td>{item.name}</td>
                  <td>{item.provider}</td>
                  <td className="mono">{item.area} · {item.distanceKm.toFixed(1)} km</td>
                  <td>
                    <span className={`status-pill ${isClaimed ? "claimed" : item.tag}`}>
                      {isClaimed ? "Claimed" : item.expiry}
                    </span>
                  </td>
                  <td>{item.qty}</td>
                  <td>{item.pickup}</td>
                  <td>
                    {item.claimedBy ? (
                      <span className="claimed-by">
                        <b>{item.claimedBy.name}</b>
                        <span className="mono">{item.claimedBy.org} · {item.claimedBy.area}</span>
                      </span>
                    ) : (
                      <span className="claimed-by-empty">—</span>
                    )}
                  </td>
                  <td>
                    <button
                      className={`dash-action${isClaimed ? " done" : ""}`}
                      disabled={isClaimed}
                      onClick={() => handleClaim(item.id)}
                    >
                      {isClaimed ? "Claimed" : "Assign / Claim"}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
