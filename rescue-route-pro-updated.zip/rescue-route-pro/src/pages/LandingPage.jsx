import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import Hero from "../components/Hero.jsx";
import ProblemSection from "../components/ProblemSection.jsx";
import HowItWorks from "../components/HowItWorks.jsx";
import FeaturesGrid from "../components/FeaturesGrid.jsx";
import LiveBoard from "../components/LiveBoard.jsx";

export default function LandingPage() {
  const { hash } = useLocation();

  useEffect(() => {
    if (!hash) return;
    const id = hash.replace("#", "");
    const t = setTimeout(() => {
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    }, 50);
    return () => clearTimeout(t);
  }, [hash]);

  return (
    <>
      <Hero />
      <ProblemSection />
      <HowItWorks />
      <FeaturesGrid />
      <LiveBoard />
    </>
  );
}
