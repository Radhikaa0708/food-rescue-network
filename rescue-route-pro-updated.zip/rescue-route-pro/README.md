# Rescue Route — Food Rescue Network

## Run it

```
npm install
npm run dev
```

Open the printed local address (usually `http://localhost:5173`).

## Project structure

```
rescue-route-pro/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx                 → mounts React + router + global CSS
    ├── App.jsx                  → app shell: loader, navbar, routes, footer
    │
    ├── pages/
    │   ├── LandingPage.jsx       → marketing/demo page (route: /)
    │   └── DashboardPage.jsx     → provider/volunteer console (route: /dashboard)
    │
    ├── components/
    │   ├── Loader.jsx            → boot-up loading screen
    │   ├── Navbar.jsx            → sticky nav with routing links
    │   ├── Hero.jsx               → landing page hero section
    │   ├── TicketCard.jsx         → live countdown "rescue ticket" card
    │   ├── ProblemSection.jsx     → problem statement block
    │   ├── HowItWorks.jsx         → 3-step process cards
    │   ├── FeaturesGrid.jsx       → core features grid
    │   ├── LiveBoard.jsx          → filterable donation listings (landing demo)
    │   └── Footer.jsx
    │
    ├── data/
    │   ├── listings.js            → sample donation listings
    │   └── features.js            → feature card content
    │
    └── styles/
        └── global.css             → all styling, single source of truth
```

## Pages

- **/** — the public landing page: hero, problem statement, how-it-works, features, and a live filterable board.
- **/dashboard** — a working console view: stat cards (total/urgent/open/claimed), and a table of listings with claim actions. This is the page a provider or volunteer would actually use day-to-day.

## Notes

- Fonts (Fraunces, IBM Plex Mono, Inter) load via Google Fonts in `index.html`.
- All state (claims, filters, countdown) is local `useState`/`useEffect` — swap the `data/` files or wire them to a real API when you have a backend.
- `npm run build` produces a `dist/` folder ready to deploy.
